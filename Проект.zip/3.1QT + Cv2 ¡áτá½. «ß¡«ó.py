from ast import Delete
from PyQt6 import QtGui, uic
from PyQt6.QtWidgets import QWidget, QApplication, QFileDialog, QInputDialog
from PyQt6.QtGui import QPixmap
import sys
import cv2
from PyQt6.QtCore import pyqtSignal, pyqtSlot, QThread
import numpy as np


class simple_VideoThread(QThread):
    change_pixmap_signal = pyqtSignal(np.ndarray)
    change_pixmap_signal1 = pyqtSignal(np.ndarray)
    change_pixmap_signal2 = pyqtSignal(np.ndarray)
    change_pixmap_signal3 = pyqtSignal(np.ndarray)

    def get_value(self, *arr):
        self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id = arr

    def run(self):
        # capture from web cam
        cap = cv2.VideoCapture(self.id)
        while True:
            ret, cv_img = cap.read()
            rgb = cv2.cvtColor(cv_img, cv2.COLOR_RGB2BGR)
            hsv = cv2.cvtColor(cv_img, cv2.COLOR_RGB2HSV)
            mask_bgr = cv2.inRange(rgb, (self.r_min, self.g_min, self.b_min), (self.r_max, self.g_max, self.b_max))
            mask_hsv = cv2.inRange(hsv, (self.h_min, self.s_min, self.v_min), (self.h_max, self.s_max, self.v_max))
            gray = cv2.cvtColor(cv_img, cv2.COLOR_RGB2GRAY)
            if ret:
                self.change_pixmap_signal.emit(cv_img)
                self.change_pixmap_signal1.emit(mask_bgr)
                self.change_pixmap_signal2.emit(mask_hsv)
                self.change_pixmap_signal3.emit(gray)

class main(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi(r'C:\Users\frozj\OneDrive\Документы\Проект на PyQt\возможный вид приложения.ui', self)
        self.id, _ = QInputDialog.getInt(self, "id камеры", "Укажите id камеры с которой стоит выводить видеопоток", 0, 0, 5, 1)

        self.fname = QFileDialog.getOpenFileName(self, 'Выберите текстовый файл', '')[0]
        try:
            self.f = open(self.fname)
            text = self.f.read()
            self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max = map(int, text.split())
        except Exception:
            self.fname = QFileDialog.getOpenFileName(self, 'Файл не подошёл. Выберите текстовый файл заново', '')[0]
            self.f = open(self.fname)
            text = self.f.read()
            self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max = map(int, text.split())
        #=======================================slider========================================
        self.horizontalSlider.setValue(self.r_min)
        self.horizontalSlider_2.setValue(self.r_max)
        self.horizontalSlider_3.setValue(self.g_min)
        self.horizontalSlider_4.setValue(self.g_max)
        self.horizontalSlider_5.setValue(self.b_min)
        self.horizontalSlider_6.setValue(self.b_max)
        self.label_r_min.setText(str(self.r_min))
        self.label_g_min.setText(str(self.g_min))
        self.label_b_min.setText(str(self.b_min))
        self.label_r_max.setText(str(self.r_max))
        self.label_g_max.setText(str(self.g_max))
        self.label_b_max.setText(str(self.b_max))
        self.horizontalSlider.valueChanged.connect(self.red_min)
        self.horizontalSlider_2.valueChanged.connect(self.red_max)
        self.horizontalSlider_3.valueChanged.connect(self.green_min)
        self.horizontalSlider_4.valueChanged.connect(self.green_max)
        self.horizontalSlider_5.valueChanged.connect(self.blue_min)
        self.horizontalSlider_6.valueChanged.connect(self.blue_max)
        self.horizontalSlider_7.setValue(self.h_min)
        self.horizontalSlider_8.setValue(self.h_max)
        self.horizontalSlider_9.setValue(self.s_min)
        self.horizontalSlider_10.setValue(self.s_max)
        self.horizontalSlider_11.setValue(self.v_min)
        self.horizontalSlider_12.setValue(self.v_max)
        self.label_h_min.setText(str(self.h_min))
        self.label_s_min.setText(str(self.s_min))
        self.label_v_min.setText(str(self.v_min))
        self.label_h_max.setText(str(self.h_max))
        self.label_s_max.setText(str(self.s_max))
        self.label_v_max.setText(str(self.v_max))
        self.horizontalSlider_7.valueChanged.connect(self.hue_min)
        self.horizontalSlider_8.valueChanged.connect(self.hue_max)
        self.horizontalSlider_9.valueChanged.connect(self.sat_min)
        self.horizontalSlider_10.valueChanged.connect(self.sat_max)
        self.horizontalSlider_11.valueChanged.connect(self.val_min)
        self.horizontalSlider_12.valueChanged.connect(self.val_max)
        #=====================================================================================
        self.count1 = 0
        self.count2 = 0
        self.label_video5.setHidden(True)
        self.label_video6.setHidden(True)
        self.tabWidget.currentChanged.connect(self.tab_a)
        self.pushButton_save1.clicked.connect(self.save)
        self.pushButton_save2.clicked.connect(self.save)
        self.pushButton.clicked.connect(self.aux_video1)
        self.pushButton_2.clicked.connect(self.aux_video2)
        self.thread = simple_VideoThread()
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)
        self.thread.change_pixmap_signal.connect(self.convert_cv_qt1)
        self.thread.change_pixmap_signal1.connect(self.convert_cv_qt2)
        self.thread.change_pixmap_signal2.connect(self.convert_cv_qt3)
        self.thread.change_pixmap_signal3.connect(self.convert_cv_qt4)
        self.thread.start()
    
    def aux_video1(self):
        if self.count1 % 2 == 0:
            self.label_video5.setHidden(False)
            self.pushButton.setText('Убрать видеопоток')
        else:
            self.label_video5.setHidden(True)
            self.pushButton.setText('Вывести видеопоток')
        self.count1 += 1
    
    def aux_video2(self):
        if self.count2 % 2 == 0:
            self.label_video6.setHidden(False)
            self.pushButton.setText('Убрать видеопоток')
        else:
            self.label_video6.setHidden(True)
            self.pushButton.setText('Вывести видеопоток')
        self.count2 += 1

    def save(self):
        text=f"{self.r_min} {self.r_max} {self.g_min} {self.g_max} {self.b_min} {self.b_max} {self.h_min} {self.h_max} {self.s_min} {self.s_max} {self.v_min} {self.v_max}"
        with open(self.fname, "w") as f:
            f.write(text)

    def convert_cv_qt1(self, cv_img):
        """Convert from an opencv image to QPixmap"""
        rgb_image = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        convert_to_Qt_format = QtGui.QImage(rgb_image.data, w, h, bytes_per_line, QtGui.QImage.Format.Format_RGB888)
        p = convert_to_Qt_format.scaled(640, 460)
        self.label_video1.setPixmap(QPixmap.fromImage(p))
        p = convert_to_Qt_format.scaled(320, 240)
        self.label_video5.setPixmap(QPixmap.fromImage(p))
        self.label_video6.setPixmap(QPixmap.fromImage(p))
    
    def convert_cv_qt2(self, cv_img):
        """Convert from an opencv image to QPixmap"""
        rgb_image = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        convert_to_Qt_format = QtGui.QImage(rgb_image.data, w, h, bytes_per_line, QtGui.QImage.Format.Format_RGB888)
        p = convert_to_Qt_format.scaled(640, 460)
        self.label_video2.setPixmap(QPixmap.fromImage(p))
    
    def convert_cv_qt3(self, cv_img):
        """Convert from an opencv image to QPixmap"""
        rgb_image = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        convert_to_Qt_format = QtGui.QImage(rgb_image.data, w, h, bytes_per_line, QtGui.QImage.Format.Format_RGB888)
        p = convert_to_Qt_format.scaled(640, 460)
        self.label_video3.setPixmap(QPixmap.fromImage(p))
    
    def convert_cv_qt4(self, cv_img):
        """Convert from an opencv image to QPixmap"""
        rgb_image = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        convert_to_Qt_format = QtGui.QImage(rgb_image.data, w, h, bytes_per_line, QtGui.QImage.Format.Format_RGB888)
        p = convert_to_Qt_format.scaled(640, 460)
        self.label_video4.setPixmap(QPixmap.fromImage(p))
    #=============================================================================slider=============================================================================================
    def red_min(self):
        self.r_min=self.horizontalSlider.value()
        self.label_r_min.setText(str(self.r_min))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)
        
    def green_min(self):
        self.g_min=self.horizontalSlider_3.value()
        self.label_g_min.setText(str(self.g_min))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)

    def blue_min(self):
        self.b_min=self.horizontalSlider_5.value() 
        self.label_b_min.setText(str(self.b_min))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)

    def red_max(self):
        self.r_max=self.horizontalSlider_2.value()
        self.label_r_max.setText(str(self.r_max))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)
        
    def green_max(self):
        self.g_max=self.horizontalSlider_4.value()
        self.label_g_max.setText(str(self.g_max))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)

    def blue_max(self):
        self.b_max=self.horizontalSlider_6.value()
        self.label_b_max.setText(str(self.b_max))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)
    
    def hue_min(self):
        self.h_min=self.horizontalSlider_7.value()
        self.label_h_min.setText(str(self.h_min))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)
        
    def sat_min(self):
        self.s_min=self.horizontalSlider_9.value()
        self.label_s_min.setText(str(self.s_min))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)

    def val_min(self):
        self.v_min=self.horizontalSlider_11.value() 
        self.label_v_min.setText(str(self.v_min))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)

    def hue_max(self):
        self.h_max=self.horizontalSlider_8.value()
        self.label_h_max.setText(str(self.h_max))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)
        
    def sat_max(self):
        self.s_max=self.horizontalSlider_10.value()
        self.label_s_max.setText(str(self.s_max))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)

    def val_max(self):
        self.v_max=self.horizontalSlider_12.value()
        self.label_v_max.setText(str(self.v_max))
        self.thread.get_value(self.r_min, self.r_max, self.g_min, self.g_max, self.b_min, self.b_max, self.h_min, self.h_max, self.s_min, self.s_max, self.v_min, self.v_max, self.id)
    #================================================================================================================================================================================
    
    def tab_a(self, i):
        pass

    

if __name__=="__main__":
    app = QApplication(sys.argv)
    a = main()
    a.show()
    sys.exit(app.exec())